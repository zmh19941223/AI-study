<script setup>

</script>

<template>
  <el-container>
    <el-header>
      <h1>控制台</h1>
    </el-header>
    <el-container>
      <h2>SpringMVC - RESTful CRUD - 练习</h2>
    </el-container>

  </el-container>


</template>

<style scoped>

</style>
